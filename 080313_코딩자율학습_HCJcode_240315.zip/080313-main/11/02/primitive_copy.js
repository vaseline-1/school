let num = 10;
let copyNum = num;
num = 20; // 변수 num을 재할당
console.log(num); // 20 
console.log(copyNum); // 10 
