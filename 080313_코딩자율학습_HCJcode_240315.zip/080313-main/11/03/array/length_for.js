const arr = [10, 20, 30];
for(let i = 0; i < arr.length; i++){
  console.log(arr[i]);
}
