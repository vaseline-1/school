console.log(num);
var num = 10;
