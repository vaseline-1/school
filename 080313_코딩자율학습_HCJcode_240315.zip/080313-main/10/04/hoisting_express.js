printHello(); 
var printHello = function printHello(){ 
  console.log("Hello");
}
