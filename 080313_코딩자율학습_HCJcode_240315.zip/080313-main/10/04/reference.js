let a = 10;
const b = 20;
function sum(){
  let a = 50;
  const b = 70;
  console.log(`함수 내부 a: ${a}`);
  console.log(`함수 내부 b: ${b}`);
}
sum();
