printHello();
function printHello(){
  console.log("Hello");
}
