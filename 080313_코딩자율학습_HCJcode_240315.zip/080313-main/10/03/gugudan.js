function gugudan(dan){
  for(let i = 1; i <= 9; i++){
    console.log(`${dan} * ${i} = ${dan * i}`);
  }
}
gugudan(3);
gugudan(5);
gugudan(8);