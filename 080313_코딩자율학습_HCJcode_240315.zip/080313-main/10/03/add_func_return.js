function sum(num1, num2){  
  let result = num1 + num2; 
  return result;
  // return num1 + num2;
}
const result = sum(10, 20);
console.log("out: " + result); // out 30
