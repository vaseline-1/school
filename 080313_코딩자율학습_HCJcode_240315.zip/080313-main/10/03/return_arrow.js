const sum = (num1, num2) => num1 + num2;
const result = sum(10, 20); // 30
