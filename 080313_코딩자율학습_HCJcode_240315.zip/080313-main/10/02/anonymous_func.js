const gugudan = function(){
  for(let i = 1; i <= 9; i++){
    console.log(`3 * ${i} = ${3 * i}`);
  }  
};
gugudan(); // 함수 호출 문제없음
