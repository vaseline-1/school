let num = 0; 
if(num > 0){
  console.log("양수");
}else if(num < 0){
  console.log("음수")
}else{
  console.log("0");
}
