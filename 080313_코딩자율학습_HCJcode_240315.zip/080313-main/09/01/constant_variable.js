const num = 10;
num = 30;
console.log(num);
