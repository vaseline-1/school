let num = -10;
num = -num; 
console.log(num); // 10
