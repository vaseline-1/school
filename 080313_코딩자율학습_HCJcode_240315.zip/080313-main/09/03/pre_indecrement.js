let num = 10;
let subNum = ++num; // 앞에 사용했으므로 전치 연산 방식
console.log(subNum); // 11
