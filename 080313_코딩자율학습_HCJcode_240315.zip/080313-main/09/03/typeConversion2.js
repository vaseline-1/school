let num = 10;
let strNum = "10";
if(num == strNum){ // 문자열을 숫자형으로 형 변환
  console.log(`equals`);
}
