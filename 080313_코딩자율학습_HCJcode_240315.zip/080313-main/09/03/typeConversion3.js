let num = 10;
let strNum = "10";
if(String(num) == strNum){
  console.log(`equals`);
}
