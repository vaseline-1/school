let num = 10;
let subNum = num++; // 뒤에 사용했으므로 후치 연산 방식
console.log(subNum); // 10
