do{
  console.log("무조건");
  console.log("한 번은 실행");
}while(false);
