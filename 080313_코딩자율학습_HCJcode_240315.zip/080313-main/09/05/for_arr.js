let arr = ["banana", "apple", "orange"];
for(let i=0; i<arr.length; i++){
  console.log(arr[i]);
}
