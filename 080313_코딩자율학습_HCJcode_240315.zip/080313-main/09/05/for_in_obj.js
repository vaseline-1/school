let obj = {name: "철수", age: "20"};
for(let key in obj){
  console.log(key + ": " + obj[key]);
}
