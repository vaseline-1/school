let arr = ["orange", "banana", "apple"];
for(let index in arr){
  console.log(index + ": " + arr[index]);
}