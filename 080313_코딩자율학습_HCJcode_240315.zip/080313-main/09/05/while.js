let num = 1;
while(num <= 9999){
  console.log(num);
  num++;
}
