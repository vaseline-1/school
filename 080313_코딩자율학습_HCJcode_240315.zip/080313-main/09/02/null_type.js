let empty = null; 
console.log(empty); // null
