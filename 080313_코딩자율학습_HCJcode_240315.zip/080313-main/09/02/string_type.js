let string1 = "Hello, World!";
let string2 = 'Hello, World!'; 

console.log(string1);
console.log(string2);
