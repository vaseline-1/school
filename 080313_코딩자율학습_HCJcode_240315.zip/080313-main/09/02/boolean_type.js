let boolean1 = true;
let boolean2 = false;
console.log(boolean1); // true
console.log(boolean2); // false
