let string1 = '문자열은 큰따옴표(")로 감싸면 됩니다.';
let string2 = "문자열은 작은따옴표(')로 감싸면 됩니다.";

console.log(string1);
console.log(string2);
