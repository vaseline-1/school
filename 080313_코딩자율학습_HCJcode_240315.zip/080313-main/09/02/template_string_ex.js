let dan = 3; 
let gugu = 8;
let string =`${dan} 곱하기 ${gugu}은 ${dan * gugu}입니다.`;
console.log(string);
